<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$conn = new mysqli("localhost", "root", "", "test");
if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}


$pseudo = $_POST['pseudo'] ?? '';
$mot_de_passe = $_POST['mot_de_passe'] ?? '';

if (empty($pseudo) || empty($mot_de_passe)) {
    die("⛔ Tous les champs doivent être remplis.");
}


$sql = "SELECT * FROM utilisateur WHERE pseudo = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $pseudo);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $utilisateur = $result->fetch_assoc();


    if (password_verify($mot_de_passe, $utilisateur['mot_de_passe'])) {
        $nom = $utilisateur['nom'];
        $age = $utilisateur['age']; 
        echo "✅ Bonjour $nom, vous avez $age ans.";
    } else {
        echo "❌ Mot de passe incorrect.";
    }
} else {
    echo "❌ Utilisateur inconnu.";
}

$stmt->close();
$conn->close();
?>
