<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$conn = new mysqli("localhost", "root", "", "test");

if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}

$pseudo = $conn->real_escape_string($_POST['pseudo']);
$mot_de_passe = $_POST['mot_de_passe'];

echo "Pseudo reçu : $pseudo <br>";
echo "Mot de passe reçu : $mot_de_passe <br>";

$sql = "SELECT * FROM utilisateur WHERE pseudo=?"; 
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $pseudo);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $utilisateur = $result->fetch_assoc();
    
  
    if ($mot_de_passe === $utilisateur['mot_de_passe']) {
        $nom = $utilisateur['nom'];
        $age = $utilisateur['âge']; 
        echo "Bonjour $nom, vous avez $age ans.";
    } else {
        echo "❌ Erreur : pseudo ou mot de passe incorrect.";
    }
} else {
    echo "❌ Erreur : pseudo ou mot de passe incorrect.";
}

$stmt->close();
$conn->close();
?>
